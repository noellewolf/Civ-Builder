var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

module.exports = router;

var express = require('express');
var router = express.Router();
var connection  = require('../database.js');
 
 
/* GET home page. */
router.get('/', function(req, res, next) {
      
 connection.query('SELECT * FROM civilizations ORDER BY id desc',function(err,rows)     {
 
        if(err){
         req.flash('error', err); 
         res.render('list',{page_title:"Civilizations - Node.js",data:''});   
        }else{
            
            res.render('list',{page_title:"Civilizations - Node.js",data:rows});
        }
                            
         });
        
    });
 
 
module.exports = router;